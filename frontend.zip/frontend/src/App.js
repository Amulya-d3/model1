import { useState } from "react";
import "./App.css";

function App() {
  const [f, setF] = useState({});
  const [result, setResult] = useState(null);

  // Handle input change
  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setF({
      ...f,
      [name]: type === "checkbox" ? (checked ? 1 : 0) : value
    });
  };

  // Send data to Node backend
  const predictRisk = async () => {
    const features = [
      Number(f.Age),                    // Age
      Number(f.BMI),                    // BMI
      Number(f.BMI_Category),           // BMI_Category
      Number(f.DiastolicBP),             // DiastolicBP
      f.BP_Risk || 0,                   // BP_Risk
      Number(f.BodyTemp),               // BodyTemp
      Number(f.HeartRate),              // HeartRate
      Number(f.Hematocrit),             // Hematocrit
      f.Anemia_Risk || 0,               // Anemia_Risk
      Number(f.SerumCreatinine),         // SerumCreatinine
      Number(f.WBC),                    // WBC
      Number(f.USG_AC),                 // USG_AC
      Number(f.USG_BPD),                // USG_BPD
      Number(f.USG_FL),                 // USG_FL
      f.Fetal_Growth_Stress || 0,       // Fetal_Growth_Stress
      Number(f.GestationalAge_Weeks),   // GestationalAge_Weeks
      Number(f.Trimester),              // Trimester
      Number(f.OGTT_Fasting),           // OGTT_Fasting
      Number(f.OGTT_1hr),               // OGTT_1hr
      Number(f.OGTT_2hr),               // OGTT_2hr
      f.Metabolic_Risk || 0             // Metabolic_Risk
    ];

    try {
      const res = await fetch("http://localhost:8000/predict", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ features })
      });

      const data = await res.json();
      setResult(data);
    } catch (err) {
      alert("Failed to connect to backend");
    }
  };

  return (
    <div className="container">
      <h2>Pregnancy Growth Risk Prediction</h2>

      {/* Basic Information */}
      <h4>Basic Information</h4>
      <input name="Age" placeholder="Age (years)" onChange={handleChange} />
      <input
        name="GestationalAge_Weeks"
        placeholder="Gestational Age (weeks)"
        onChange={handleChange}
      />
      <select name="Trimester" onChange={handleChange}>
        <option value="">Select Trimester</option>
        <option value="1">1st Trimester</option>
        <option value="2">2nd Trimester</option>
        <option value="3">3rd Trimester</option>
      </select>

      {/* Body & Metabolic */}
      <h4>Body & Metabolic Health</h4>
      <input name="BMI" placeholder="BMI" onChange={handleChange} />
      <select name="BMI_Category" onChange={handleChange}>
        <option value="">Select BMI Category</option>
        <option value="0">Underweight</option>
        <option value="1">Normal</option>
        <option value="2">Overweight</option>
        <option value="3">Obese</option>
      </select>
      <label>
        <input
          type="checkbox"
          name="Metabolic_Risk"
          onChange={handleChange}
        />{" "}
        Metabolic Risk
      </label>

      {/* Vitals */}
      <h4>Vitals & Blood Pressure</h4>
      <input
        name="DiastolicBP"
        placeholder="Diastolic Blood Pressure"
        onChange={handleChange}
      />
      <label>
        <input type="checkbox" name="BP_Risk" onChange={handleChange} /> BP Risk
      </label>
      <input
        name="BodyTemp"
        placeholder="Body Temperature (°C)"
        onChange={handleChange}
      />
      <input
        name="HeartRate"
        placeholder="Heart Rate (bpm)"
        onChange={handleChange}
      />

      {/* Blood & Lab */}
      <h4>Blood & Laboratory Parameters</h4>
      <input
        name="Hematocrit"
        placeholder="Hematocrit (%)"
        onChange={handleChange}
      />
      <label>
        <input
          type="checkbox"
          name="Anemia_Risk"
          onChange={handleChange}
        />{" "}
        Anemia Risk
      </label>
      <input
        name="SerumCreatinine"
        placeholder="Serum Creatinine"
        onChange={handleChange}
      />
      <input
        name="WBC"
        placeholder="WBC Count"
        onChange={handleChange}
      />

      {/* Ultrasound */}
      <h4>Ultrasound Findings</h4>
      <input name="USG_AC" placeholder="USG AC" onChange={handleChange} />
      <input name="USG_BPD" placeholder="USG BPD" onChange={handleChange} />
      <input name="USG_FL" placeholder="USG FL" onChange={handleChange} />
      <label>
        <input
          type="checkbox"
          name="Fetal_Growth_Stress"
          onChange={handleChange}
        />{" "}
        Fetal Growth Stress
      </label>

      {/* OGTT */}
      <h4>OGTT (Diabetes Screening)</h4>
      <input
        name="OGTT_Fasting"
        placeholder="OGTT Fasting"
        onChange={handleChange}
      />
      <input
        name="OGTT_1hr"
        placeholder="OGTT 1 Hour"
        onChange={handleChange}
      />
      <input
        name="OGTT_2hr"
        placeholder="OGTT 2 Hour"
        onChange={handleChange}
      />

      <br />
      <button onClick={predictRisk}>Predict Risk</button>

      {result && (
        <div className="result">
          <p>
            <b>Prediction Value:</b> {result.prediction}
          </p>
          <p>
            <b>Risk Status:</b> {result.result}
          </p>
        </div>
      )}
    </div>
  );
}

export default App;
